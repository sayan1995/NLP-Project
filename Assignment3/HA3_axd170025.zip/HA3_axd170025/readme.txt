
Assignment 3

Arpita Dutta (axd170025)

------------------------------------------------------------------------------------------
Run the following commands to run the program:
----------------------------------------------

Step 1) Run the following command to run the file


$ pip install numpy
$ pip install pandas
$ pip install nltk
$ pip install wordnet


Navigate to the directory where you have unizipped the files
$ cd HA3_axd170025
$ python rank_model.py /people/cs/s/sanda/cs6322/Cranfield/ /people/cs/s/sanda/cs6322/resourcesIR/stopwords /people/cs/s/sanda/cs6322/hw3.queries

  python <filename> <filepath to Cranfield documents folder> <filepath to stopwords file> <filepath to hw3.queries>

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
To view the Program out- 

$ cat Output.txt

To view the Questions and Answers :

$ cat QA_document.txt